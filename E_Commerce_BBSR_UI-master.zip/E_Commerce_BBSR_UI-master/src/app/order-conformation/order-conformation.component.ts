import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-conformation',
  templateUrl: './order-conformation.component.html',
  styleUrls: ['./order-conformation.component.css']
})
export class OrderConformationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
